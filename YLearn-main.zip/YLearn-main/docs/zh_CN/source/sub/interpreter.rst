******************************************
解释器：解释因果效应
******************************************

为了解释由不同的估计模型估计的因果效应，当前版本的YLearn为了因果效应的可解释性实现了树模型 :class:`CEInterpreter` 并且为了策略估计的可解释性
实现了 :class:`PolicyInterpreter` 。


.. toctree::

    inter_model/ce_interpreter
    inter_model/policy_interpreter