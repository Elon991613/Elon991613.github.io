class AdjustmentSet:
    def __init__(self) -> None:
        pass